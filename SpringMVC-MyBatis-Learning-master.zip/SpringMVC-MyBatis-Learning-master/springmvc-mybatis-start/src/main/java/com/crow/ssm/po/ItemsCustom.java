package com.crow.ssm.po;


public class ItemsCustom extends Items {
	
	//添加商品信息的扩展属性

}
