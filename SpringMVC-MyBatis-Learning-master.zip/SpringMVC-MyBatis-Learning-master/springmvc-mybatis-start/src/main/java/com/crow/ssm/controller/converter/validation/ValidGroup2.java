package com.crow.ssm.controller.converter.validation;

/**
 * Created by CrowHawk on 17/4/7.
 */
public interface ValidGroup2 {
}
