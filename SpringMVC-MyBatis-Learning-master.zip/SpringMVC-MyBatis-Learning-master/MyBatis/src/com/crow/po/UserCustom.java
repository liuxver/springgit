package com.crow.po;

/**
 * Created by CrowHawk on 17/3/20.
 */
public class UserCustom extends User {
}
