/**
 * Created by Administrator on 2017/2/14.
 */
$(document).ready(function (){
    alert("OK TEST");
});